package application;
	
import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

//import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;

import java.io.IOException;


public class Main extends Application {
	//JSONArray jrr = new JSONArray();
	
	@Override
    public void start(Stage stage) throws IOException {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("loginPage.fxml"));
            Scene loginPage = new Scene(root);
            stage.setScene(loginPage);
            stage.show();
        } catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void main(String[] args) {
        launch();
        


    }
}
