package application;

import javafx.event.ActionEvent;
import java.io.IOException;

//import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;

public class SampleController {
	private Stage stage;
    private Scene scene;
    private Parent root;   
//    JSONArray jrr = new JSONArray();

    


    //Login Page
    
    @FXML
    private TextField logUsername;
    @FXML
    private PasswordField logPassword;
    @FXML
    private Label invalidLabel;
    
    @FXML
    public void loginButtonPress(ActionEvent event) throws IOException {
        
    	
//    	JSONObject obj = new JSONObject();
//    	int size = jrr.size();
//    	obj.put("Username", regiUsername.getText());
//    	obj.put("Password", regiPassword.getText());
    	
//    	for(int i=0;i<size;i++) {
//    	if (obj.equals(jrr.get(i))) {
    		Parent root = FXMLLoader.load(getClass().getResource("Main_page.fxml"));
            stage =(Stage) (((Node)(event.getSource())).getScene().getWindow());
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
//            break;
//    	} else if(i==size-1){
//    		invalidLabel.setText("Invalid Login");
//    	}
//    	}
    	
    }

    @FXML
    public void selfRegisterButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("registrationPage.fxml"));
        stage = (Stage) (((Node)(event.getSource())).getScene().getWindow());
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    //Register Page
    @FXML
    private TextField regiUsername;
    @FXML
    private TextField regiPassword;
    @FXML
    private Label shortPass;

    public void finishRegisterButtonPress(ActionEvent event) throws IOException {
        if (regiPassword.getText().length() >= 6) {
//        	JSONObject obj = new JSONObject();
//        	obj.put("Username", regiUsername.getText());
//        	obj.put("Password", regiPassword.getText());
//        	
//        	jrr.add(obj);
        	
        	Parent root = FXMLLoader.load(getClass().getResource("Main_page.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else {
        	shortPass.setText("Password too short");
        }
        
    }

    public void backToLoginButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("loginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    
    
    //Main Page
    
    @FXML
    private Button addToCart1;
    @FXML
    private Button addToCart2;
    @FXML
    private Button addToCart3;
    @FXML
    private Button addToCart4;
    @FXML
    private Button toCartButton;
    
    
    public void signOutButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("loginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void goToCartButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Shopping_cart.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void salesReportButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SalesReportPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void addToCartButton1(ActionEvent event) {
    	toCartButton.setVisible(true);
    }
    
    public void addToCartButton2(ActionEvent event) {
    	toCartButton.setVisible(true);
    }

    public void addToCartButton3(ActionEvent event) {
    	toCartButton.setVisible(true);
    }

    public void addToCartButton4(ActionEvent event) {
    	toCartButton.setVisible(true);
    }
    
    
    //cart page
    
    
    public void continueShoppingButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Main_page.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void checkOutButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ShippingInformation.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    //shipping info page
    
    public void backToCartButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Shopping_cart.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private TextField shippingAddress;
    @FXML
    private TextField phoneNumber;
    @FXML
    private TextField ccNumber;
    @FXML
    private TextField expirationDate;
    @FXML
    private TextField CVV;

    @FXML
public void confirmOrderButtonPress(ActionEvent event) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("Order_confirmation.fxml"));
    stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}

public void Overnight(ActionEvent event) throws IOException
    {

    }

    public void threeDay(ActionEvent event) throws IOException
    {

    }
    public void Ground(ActionEvent event) throws IOException
    {

    }
    //receipt page
    
    public void moreShoppingButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Main_page.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void doneShoppingButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("loginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    //sales report
    
    public void exitReportButtonPress(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Main_page.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
